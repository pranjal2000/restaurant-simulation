// If given number (of queue, burgers, etc.) is not valid
public class IllegalNumberException extends Exception{
    IllegalNumberException(String s){
        super(s);
    }
}
