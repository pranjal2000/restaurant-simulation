

public class MMBurgers implements MMBurgersInterface {

    public boolean isEmpty(){
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 
    
    public void setK(int k) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    }   
    
    public void setM(int m) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public void advanceTime(int t) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public void arriveCustomer(int id, int t, int numb) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int customerState(int id, int t) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int griddleState(int t) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int griddleWait(int t) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int customerWaitTime(int id) throws IllegalNumberException{
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

	public float avgWaitTime(){
        //your implementation
	    throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    
}
